#!/usr/bin/env bash

SXHKD_CNT=`ps -A | grep 'sxhkd' | wc -l`;
if [[ $SXHKD_CNT -lt 1 ]]; then
    sxhkd &
fi;
